#pragma once
#define ArrivalRate 30.0
#define LAST 100
int cars = 1;
double rideSize = 36;
double loadTime = 62;
double unloadTime = 16;
double rideTime = 102;