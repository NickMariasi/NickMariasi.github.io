package com.cornez.codeTutorial;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.cornez.actionbarexperimenti.R;

public class cplusplusTestActivity extends Activity {

    private Button homeButton;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            TextView cplusplusQuestion1 =
                    (TextView)findViewById(R.id.cplusplusQuestion1);  //just right.
            cplusplusQuestion1.setText("'For' Loop");
        }
    };

    Handler handler2 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            TextView textView7 =
                    (TextView)findViewById(R.id.textView7);  //messed up name of textviews and buttons -- works as intended though
            textView7.setText("iostream");
        }
    };

    Handler handler3 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            TextView textView8 =
                    (TextView)findViewById(R.id.textView8);  //messed up name of textviews and buttons -- works as intended though
            textView8.setText("True");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cplusplus_test);

        homeButton = (Button) findViewById(R.id.buttonHome);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchHome();
            }
        });
    }

    public void buttonClick(View view)
    {

        Runnable runnable = new Runnable() {
            public void run() {

                long endTime = System.currentTimeMillis();

                while (System.currentTimeMillis() < endTime) {
                    synchronized (this) {
                        try {
                            wait(endTime -
                                    System.currentTimeMillis());
                        } catch (Exception e) {}
                    }

                }
                handler.sendEmptyMessage(0);
            }
        };

        Thread mythread = new Thread(runnable);
        mythread.start();

    }

    public void buttonClick2(View view)
    {

        Runnable runnable = new Runnable() {
            public void run() {

                long endTime = System.currentTimeMillis();

                while (System.currentTimeMillis() < endTime) {
                    synchronized (this) {
                        try {
                            wait(endTime -
                                    System.currentTimeMillis());
                        } catch (Exception e) {}
                    }

                }
                handler2.sendEmptyMessage(0);
            }
        };

        Thread mythread = new Thread(runnable);
        mythread.start();

    }

    public void buttonClick3(View view)
    {

        Runnable runnable = new Runnable() {
            public void run() {

                long endTime = System.currentTimeMillis();

                while (System.currentTimeMillis() < endTime) {
                    synchronized (this) {
                        try {
                            wait(endTime -
                                    System.currentTimeMillis());
                        } catch (Exception e) {}
                    }

                }
                handler3.sendEmptyMessage(0);
            }
        };

        Thread mythread = new Thread(runnable);
        mythread.start();

    }

    private void launchHome() {
        Intent intent = new Intent(this, homescreen.class);
        startActivity(intent);
    }

}
