#pragma once
#include <string>
#define ArrivalRate 30.0
#define LAST 109
int cars = 1;
double rideSize = 30;
double loadTime = 60;
double unloadTime = 15;
double rideTime = 90;
