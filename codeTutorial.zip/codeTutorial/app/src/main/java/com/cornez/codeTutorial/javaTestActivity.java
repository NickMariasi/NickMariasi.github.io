package com.cornez.codeTutorial;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.cornez.actionbarexperimenti.R;

public class javaTestActivity extends Activity {

    private Button javaHomeButton;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            TextView javaTestQ1 =
                    (TextView)findViewById(R.id.javaTestQ1);  //just right.
            javaTestQ1.setText("False");
        }
    };

    Handler handler2 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            TextView javaTestQ2 =
                    (TextView)findViewById(R.id.javaTestQ2);  //messed up name of textviews and buttons -- works as intended though
            javaTestQ2.setText("java.util.Scanner");
        }
    };

    Handler handler3 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            TextView javaTestQ3 =
                    (TextView)findViewById(R.id.javaTestQ3);  //messed up name of textviews and buttons -- works as intended though
            javaTestQ3.setText("False");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_test);

        javaHomeButton = (Button) findViewById(R.id.javaReturnHome);
        javaHomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                javaLaunchHome();
            }
        });

    }

    public void buttonClick(View view)
    {

        Runnable runnable = new Runnable() {
            public void run() {

                long endTime = System.currentTimeMillis();

                while (System.currentTimeMillis() < endTime) {
                    synchronized (this) {
                        try {
                            wait(endTime -
                                    System.currentTimeMillis());
                        } catch (Exception e) {}
                    }

                }
                handler.sendEmptyMessage(0);
            }
        };

        Thread mythread = new Thread(runnable);
        mythread.start();

    }

    public void buttonClick2(View view)
    {

        Runnable runnable = new Runnable() {
            public void run() {

                long endTime = System.currentTimeMillis();

                while (System.currentTimeMillis() < endTime) {
                    synchronized (this) {
                        try {
                            wait(endTime -
                                    System.currentTimeMillis());
                        } catch (Exception e) {}
                    }

                }
                handler2.sendEmptyMessage(0);
            }
        };

        Thread mythread = new Thread(runnable);
        mythread.start();

    }

    public void buttonClick3(View view)
    {

        Runnable runnable = new Runnable() {
            public void run() {

                long endTime = System.currentTimeMillis();

                while (System.currentTimeMillis() < endTime) {
                    synchronized (this) {
                        try {
                            wait(endTime -
                                    System.currentTimeMillis());
                        } catch (Exception e) {}
                    }

                }
                handler3.sendEmptyMessage(0);
            }
        };

        Thread mythread = new Thread(runnable);
        mythread.start();

    }

    private void javaLaunchHome() {
        Intent intent = new Intent(this, homescreen.class);
        startActivity(intent);
    }


}
