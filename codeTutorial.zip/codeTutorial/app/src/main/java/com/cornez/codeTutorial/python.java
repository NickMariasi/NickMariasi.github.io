package com.cornez.codeTutorial;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.cornez.actionbarexperimenti.R;


public class python extends Activity {

    private Button pTest;

    private static final String TAB_KEY_INDEX = "tab_key";
    private Fragment loopPythonFragment;
    private Fragment inputPythonFragment;
    private Fragment outputPythonFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_python);

        pTest = (Button) findViewById(R.id.pContinueTest);

        pTest.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                pContinueTest();
            }
        });

        //SET THE ACTIONBAR AND CREATE THE TABS
        ActionBar actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        actionBar.setDisplayShowTitleEnabled(false);

        ActionBar.Tab pythonloopTab = actionBar.newTab().setText(
                "Loop Tutorial");
        ActionBar.Tab pythoninputTab = actionBar.newTab().setText(
                "Input Tutorial");
        ActionBar.Tab pythonoutputTab = actionBar.newTab().setText(
                "Output Tutorial");

        //CREATE EACH FRAGMENT AND BIND THEM TO THE ACTIONBAR
        loopPythonFragment = new loopPythonFragment();
        inputPythonFragment = new inputPythonFragment();
        outputPythonFragment = new outputPythonFragment();

        //SET LISTENER EVENTS FOR EACH OF THE ACTIONBAR TABS
        pythonloopTab.setTabListener(new MyTabsListener(loopPythonFragment,
                getApplicationContext()));
        pythoninputTab.setTabListener(new MyTabsListener(inputPythonFragment,
                getApplicationContext()));
        pythonoutputTab.setTabListener(new MyTabsListener(outputPythonFragment,
                getApplicationContext()));

        //ADD EACH OF THE TABS TO THE ACTIONBAR
        actionBar.addTab(pythonloopTab);
        actionBar.addTab(pythoninputTab);
        actionBar.addTab(pythonoutputTab);

        // RESTORE NAVIGATION
        if (savedInstanceState != null) {
            actionBar.setSelectedNavigationItem(savedInstanceState.getInt(
                    TAB_KEY_INDEX, 0));
        }

    }

    class MyTabsListener implements ActionBar.TabListener {
        public Fragment fragment;

        public MyTabsListener(Fragment f, Context context) {
            fragment = f;
        }

        @Override
        public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {
        }

        @Override
        public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
            ft.replace(R.id.fragment_container, fragment);
        }

        @Override
        public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
            ft.remove(fragment);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.homeButton) {
            Intent intent = new Intent(this, homescreen.class);
            startActivity(intent);
        }
        if (id == R.id.aboutScreen){
            Intent intent = new Intent(this, aboutScreen.class);
            startActivity(intent);
        }
        if (id == R.id.pythonSwitch) {
            return true;
        }
        if (id == R.id.javaSwitch) {
            Intent intent = new Intent (this, java.class);
            startActivity(intent);
        }
        if (id == R.id.cplusplusSwitch){
            Intent intent = new Intent(this, cplusplus.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void pContinueTest() {
        Intent intent = new Intent(this, pythonTestActivity.class);
        startActivity(intent);
    }
}


