package com.cornez.codeTutorial;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

import com.cornez.actionbarexperimenti.R;

public class aboutScreen extends Activity {

    private Button mBtHomescreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_screen);

        mBtHomescreen = (Button) findViewById(R.id.returnHome);

        mBtHomescreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchHomescreen();
            }
        });

    }

    private void launchHomescreen(){
        Intent intent = new Intent(this, homescreen.class);
        startActivity(intent);
    }

}
