#pragma once
#include <iostream>
#include <time.h>
using namespace std;
int state;
double Random(void)
{
	const long A = 48271;      //Multiplier
	const long M = 2147483647; //Modulus
	const long Q = M / A;      //Quotient
	const long R = M % A;      //Remainder
	//initialize the seed

	// t = multiplier * (seed / quotient) - remainder * (seed / Quotient)
	long t = A * (state % Q) - R * (state / Q);
	if (t > 0)
		state = t;
	else
		state = t + M;

	return ((double)state / M);
}

void PutSeed(long seed) {
	if (seed > 0) { //CASE: Seedis positive
		cout << "You've entered " << seed << " as the seed which is ok, here's the results:" << endl;
		state = seed;
	}
	if (seed == 0) { //CASE: Seed is 0
		cout << "Seed cannot be 0 -- please enter a new seed: ";
		cin >> seed;  //get a seed from input
		state = seed;
	}
	if (seed < 0) {  //CASE: Seed is negative
		seed = time(NULL);  //assigns a random time (number)
		cout << "Seed is negative -- assigning clock value " << seed << endl; //Prints the number it used
		state = seed;
	}
}