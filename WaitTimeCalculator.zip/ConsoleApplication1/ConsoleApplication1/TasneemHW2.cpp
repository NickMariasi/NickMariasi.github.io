//Name: Nick Mariasi

#include <stdio.h>
#include <math.h>
#include "Random.h"
#include "elToroTwo.h"
#include <string>

#define START 0.0 /* initial time */

double Exponential(double m)  //USE THIS
/* ---------------------------------------------------
* generate an Exponential random variate, use m > 0.0
* ---------------------------------------------------
*/
{
	return (-m * log(1.0 - Random()));
}

double Uniform(double a, double b)

/* --------------------------------------------
* generate a Uniform random variate, use a < b
* --------------------------------------------
*/
{
	return (a + (b - a) * Random());
}

double GetArrival(void)
/* ------------------------------
* generate the next arrival time
* ------------------------------
*/
{
	static double arrival = START;
	arrival += Exponential(ArrivalRate);
	return (arrival);
}

int main(void)

{
	long index = 0; /* job index */
	double arrival = START; /* time of arrival */
	double delay; /* delay in queue */
	double service; /* service time */
	double wait; /* delay + service */
	double departure = START; /* time of departure */
	struct { /* sum of ... */
		double delay; /* delay times */
		double wait; /* wait times */
		double service; /* service times */
		double interarrival; /* interarrival times */
	} sum = { 0.0, 0.0, 0.0 };

	PutSeed(12345);  //enter the seed you wish to input


	while (index < LAST) {
		index++;
		arrival = GetArrival();
		if (arrival < departure)
			delay = departure - arrival; /* delay in queue */
		else
			delay = 0.0; /* no delay */

		service = loadTime + unloadTime + rideTime;
		wait = delay + service;
		departure = arrival + wait; /* time of departure */
		sum.delay += delay;
		sum.wait += wait;
		sum.service += service;

		//if (index % 50 == 0) { //if the remainder of index is 0 it must be at an interval of 50
			//printf("Job %d's average wait number = %6.2f\n", index, sum.wait / index);  //%ld goes to index
		//}
	}
	sum.interarrival = arrival - START;
	cout << "For " << index * rideSize << " customers served in approximately 5 hours in "<< cars << " car(s) " << "for Superman: The Ride at Six Flags New England with an arrival rate of " << rideSize << " customers in " << ArrivalRate / 60 << " Minute(s)" << endl;
	cout << "Average interarrival time = " << (sum.interarrival / index) / 60 << " Minutes" << endl;
	cout << "Average wait time = " << (sum.wait / index) / 60 << " Minutes" << endl;
	cout << "Average Delay = " << (sum.delay / index) / 60 << " Minutes" << endl;
	cout << "Average service time = " << (sum.service / index) / 60 << " Minutes" <<endl;
	printf("Minutes ran = %6.2f\n", sum.service / 60);
	printf("Hours ran = %6.2f\n", (sum.service / 60) / 60);
	return (0);
}