#pragma once
#define ArrivalRate 30.0
#define LAST 200
int cars = 2;
double rideSize = 30;
double loadTime = 0;
double unloadTime = 0;
double rideTime = 90;