package com.cornez.codeTutorial;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.app.Activity;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;

import com.cornez.actionbarexperimenti.R;

public class homescreen extends Activity {

    private Button mBtLaunchActivity;
    private Button mBtLaunchPython;
    private Button mBtLaunchJava;
    private SoundPool soundPool;
    private SparseIntArray soundMap;
    private MediaPlayer mMediaPlayer;
    private MediaController mMediaController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);
        //FOR SOUNDS WHEN CLICKING BUTTON
        configureSounds();
        mBtLaunchActivity = (Button) findViewById(R.id.cppButton);

        mBtLaunchActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(1,1,1,1,0,1.0f);
                launchActivity();
            }
        });
        //MAKE BUTTON SWITCH SCREENS TO PYTHON
        mBtLaunchPython = (Button) findViewById(R.id.pythonButton);

        mBtLaunchPython.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(2,1,1,1,0,1.0f);
                launchPython();
            }
        });
        //MAKE BUTTON SWITCH SCREENS TO JAVA
        mBtLaunchJava = (Button) findViewById(R.id.javaButton);

        mBtLaunchJava.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPool.play(3,1,1,1,0,1.0f);
                launchJava();
            }
        });

        //mBtLaunchJava.setOnClickListener(playSoundEffect);
        //mBtLaunchPython.setOnClickListener(playSoundEffect);
        //mBtLaunchActivity.setOnClickListener(playSoundEffect);
    }
    //FOR SWITCHING SCREEN FOR C++
    private void launchActivity() {
        Intent intent = new Intent(this, cplusplus.class);
        startActivity(intent);
    }
    //FOR SWITCHING SCREENS FOR PYTHON
    private void launchPython() {
        Intent intent = new Intent(this, python.class);
        startActivity(intent);
    }
    //FOR SWITCHING SCREENS FOR JAVA
    private void launchJava() {
        Intent intent = new Intent(this, java.class);
        startActivity(intent);
    }


    private void configureSounds(){
        soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        soundMap = new SparseIntArray(3);
        soundMap.put(1, soundPool.load(this, R.raw.double_click,1));
        soundMap.put(2, soundPool.load(this, R.raw.glass_button, 1));
        soundMap.put(3, soundPool.load(this, R.raw.stone_button,1));
    }

    private View.OnClickListener playSoundEffect = new View.OnClickListener() {
        public void onClick (View btn){
            //IDENTIFY SOUND TO BE PLAYED
            String soundName = (String) btn.getContentDescription();

            //PLAY THE SOUND!!!
            if (soundName.contentEquals("c++")){
                soundPool.play(1,1,1,1,0,1.0f);
            }
            else if (soundName.contentEquals("python")){
                soundPool.play(2,1,1,1,0,1.0f);
            }
            else if (soundName.contentEquals("java")){
                soundPool.play(3,1,1,1,0,1.0f);
            }
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //the MediaController will hide after 3 seconds - tap the screen to make it appear again
        mMediaController.show();
        return false;
    }
    //App crashes for WHATEVER REASON when you click on whitespace -- DO NOT DELETE THIS OR IN XML THE ONCLICK EVENT
    public void clear(View v) {
        // do nothing
    }
    }


