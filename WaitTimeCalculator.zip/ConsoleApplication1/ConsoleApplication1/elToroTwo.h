#pragma once
#define ArrivalRate 30.0
#define LAST 176
int cars = 2;
double rideSize = 36;
double loadTime = 0;
double unloadTime = 0;
double rideTime = 102;